package com.yourname.riverpod_mastery

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
